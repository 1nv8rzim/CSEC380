from request import WebCrawler

WebCrawler('rit.edu/', https=True, depth=4, threads=20, processes=4)
